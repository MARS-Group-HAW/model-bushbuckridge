cd model/Starter
dotnet run -l -sm ../../config.json --project Starter.csproj
