# model-bushbuckridge

Base model for Ulfia's and Florian's firewood collectors and for EMSAfrica scenario